import json
import boto3
import os

def handler(event, context):
    try:
        # Get RDS token for IAM authentication
        rds_client = boto3.client('rds')
        token = rds_client.generate_db_auth_token(
            DBHostname=os.environ['RDS_ENDPOINT'],
            Port=5432,
            DBUsername=os.environ['DB_USER'],
            Region=os.environ['REGION']
        )
        
        # Test database connection
        import psycopg2
        conn = psycopg2.connect(
            host=os.environ['RDS_ENDPOINT'],
            port=5432,
            database=os.environ['DB_NAME'],
            user=os.environ['DB_USER'],
            password=token,
            sslmode='require'
        )
        
        cursor = conn.cursor()
        cursor.execute("SELECT version();")
        db_version = cursor.fetchone()[0]
        cursor.close()
        conn.close()
        
        return {
            'statusCode': 200,
            'body': json.dumps({
                'message': 'Successfully connected to Aurora Serverless',
                'rds_endpoint': os.environ['RDS_ENDPOINT'],
                'db_user': os.environ['DB_USER'],
                'db_version': db_version
            })
        }
    except Exception as e:
        return {
            'statusCode': 500,
            'body': json.dumps({
                'error': str(e)
            })
        }
